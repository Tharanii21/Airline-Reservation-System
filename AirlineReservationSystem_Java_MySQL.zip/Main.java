import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        int userId = -1;

        System.out.println("1. Register\n2. Login");
        int choice = sc.nextInt();

        System.out.print("Username: ");
        String username = sc.next();

        System.out.print("Password: ");
        String password = sc.next();

        if (choice == 1) {
            if (UserService.register(username, password)) {
                System.out.println("Registered successfully!");
            } else {
                System.out.println("Registration failed.");
            }
        } else if (choice == 2) {
            userId = UserService.login(username, password);
            if (userId != -1) {
                System.out.println("Login successful!");

                while (true) {
                    System.out.println("\n1. View Flights\n2. Book Ticket\n3. Exit");
                    int ch = sc.nextInt();

                    if (ch == 1) {
                        FlightService.viewFlights();
                    } else if (ch == 2) {
                        System.out.print("Enter Flight ID to book: ");
                        int fid = sc.nextInt();
                        BookingService.bookFlight(userId, fid);
                    } else {
                        break;
                    }
                }

            } else {
                System.out.println("Login failed.");
            }
        }

        sc.close();
    }
}