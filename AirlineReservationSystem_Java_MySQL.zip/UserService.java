import java.sql.*;

public class UserService {
    public static boolean register(String username, String password) throws Exception {
        Connection con = DBConnection.getConnection();
        PreparedStatement ps = con.prepareStatement("INSERT INTO users(username, password) VALUES (?, ?)");
        ps.setString(1, username);
        ps.setString(2, password);
        return ps.executeUpdate() > 0;
    }

    public static int login(String username, String password) throws Exception {
        Connection con = DBConnection.getConnection();
        PreparedStatement ps = con.prepareStatement("SELECT id FROM users WHERE username=? AND password=?");
        ps.setString(1, username);
        ps.setString(2, password);
        ResultSet rs = ps.executeQuery();
        return rs.next() ? rs.getInt("id") : -1;
    }
}