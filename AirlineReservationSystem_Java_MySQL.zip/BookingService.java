import java.sql.*;

public class BookingService {
    public static void bookFlight(int userId, int flightId) throws Exception {
        Connection con = DBConnection.getConnection();
        
        PreparedStatement ps1 = con.prepareStatement("SELECT seats FROM flights WHERE id=?");
        ps1.setInt(1, flightId);
        ResultSet rs = ps1.executeQuery();
        if (rs.next() && rs.getInt("seats") > 0) {
            PreparedStatement ps2 = con.prepareStatement("INSERT INTO bookings(user_id, flight_id) VALUES (?, ?)");
            ps2.setInt(1, userId);
            ps2.setInt(2, flightId);
            ps2.executeUpdate();

            PreparedStatement ps3 = con.prepareStatement("UPDATE flights SET seats = seats - 1 WHERE id=?");
            ps3.setInt(1, flightId);
            ps3.executeUpdate();

            System.out.println("Booking successful!");
        } else {
            System.out.println("No seats available.");
        }
    }
}