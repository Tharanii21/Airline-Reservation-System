import java.sql.*;

public class FlightService {
    public static void viewFlights() throws Exception {
        Connection con = DBConnection.getConnection();
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery("SELECT * FROM flights");
        while (rs.next()) {
            System.out.println(rs.getInt("id") + " - " + rs.getString("flight_name") + 
                " (" + rs.getString("source") + " to " + rs.getString("destination") + 
                ") on " + rs.getDate("date") + " | Seats: " + rs.getInt("seats"));
        }
    }
}